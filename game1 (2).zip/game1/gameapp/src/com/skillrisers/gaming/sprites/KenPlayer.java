package com.skillrisers.gaming.sprites;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class KenPlayer extends Sprite {
	private BufferedImage walkImages [] = new BufferedImage[6];

	private BufferedImage standingImages [] = new BufferedImage[8];
	private BufferedImage kickImages [] = new BufferedImage[6];
	private BufferedImage punchImages [] = new BufferedImage[6];
	private BufferedImage powerimage [] = new BufferedImage[9];
	private BufferedImage jumpimage [] = new BufferedImage[7];
	private BufferedImage damageImages[] = new BufferedImage[5];
	
	public KenPlayer() throws IOException {
		x = GWIDTH - 500;
		
		y = FLOOR - h;
		currentMove = STANDING;
		speed = 0;
		image = ImageIO.read(RyuPlayer.class.getResource(KEN_IMAGE));
		loadWalkImages();
		loadStandingImages();
		loadKickImages();
		loadPunchImages();
		loadpowerimage();
		loadjump();
		loadDamageImage();
	}
	
	
	public void jump() {
		if(!isJump) {
		force = DEFAULT_FORCE;
		y = y + force;
		isJump = true;
		}
	}
	
	public void fall() {
		if(y>= (FLOOR - h)) {
			isJump = false;
			return ;
		}
		force = force + GRAVITY;
		y = y + force;
	}
	private void loadDamageImage() {
		damageImages[0] = image.getSubimage(1361, 3275, 67, 93);
		damageImages[1] = image.getSubimage(1437, 3273, 84, 100);
		damageImages[2] = image.getSubimage(1535, 3276, 81, 93);
		damageImages[3] = image.getSubimage(1628, 3277, 70, 96);
		damageImages[4] = image.getSubimage(1709, 3275, 65, 92);
	}
	private void loadjump() {
		jumpimage[0]=image.getSubimage(2037,1055,56,91);
		jumpimage[1]=image.getSubimage(1943,965,87,111);
		jumpimage[2]=image.getSubimage(1818,973,127,73);
		jumpimage[3]=image.getSubimage(1758,955,73,88);
		jumpimage[4]=image.getSubimage(1636,959,116,102);
		jumpimage[5]=image.getSubimage(1565,969,77,108);
		jumpimage[6]=image.getSubimage(1510,1029,66,115);
	}
	
	private void loadWalkImages() {
		walkImages[0]  = image.getSubimage(1551,865,57,92);
		walkImages[1]  = image.getSubimage(1480,861,59,95);
		walkImages[2]  = image.getSubimage(1408,863,63,98);
		walkImages[3]  = image.getSubimage(1337,862,59,100);
		walkImages[4]  = image.getSubimage(1264,863,61,98);
		walkImages[5]  = image.getSubimage(1688,868,64,88);
	}
	private void loadpowerimage() {
		powerimage[0]= image.getSubimage(2018,2741,78,93);
		powerimage[1]= image.getSubimage(1922,2745,88,86);
		powerimage[2]= image.getSubimage(1819,2749,91,88);
		powerimage[3]= image.getSubimage(1696,2755,112,77);
		powerimage[4]= image.getSubimage(1648,2750,50,94);
		powerimage[5]= image.getSubimage(1572,2752,69,86);
		powerimage[6]= image.getSubimage(1525,2755,33,83);
		powerimage[7]= image.getSubimage(1486,2764,36,70);
		powerimage[8]= image.getSubimage(1427,2764,50,72);
	}
	
	private void loadStandingImages() {
		standingImages[0] = image.getSubimage(1963,686,62,93);
		standingImages[1] = image.getSubimage(1829,679,59,98);
		standingImages[2] = image.getSubimage(1691,689,64,90);
		standingImages[3] = image.getSubimage(1624,679,56,99);
		standingImages[4] = image.getSubimage(1552,678,56,100);
		standingImages[5] = image.getSubimage(1482,682,57,99);
		
	}
	
	private void loadKickImages() {
		kickImages[0] = image.getSubimage(1662,1918,60,97);
		kickImages[1] = image.getSubimage(1586,1919,60,96);
		kickImages[2] = image.getSubimage(1526,1890,52,124);
		kickImages[3] = image.getSubimage(1400,1902,97,109);
		kickImages[4] = image.getSubimage(1335,1919,48,94);
		kickImages[5] = image.getSubimage(1259,1920,66,93);
				
	}
	private void loadPunchImages() {
		punchImages[0] = image.getSubimage(1360,1262,68,98);
		punchImages[1] = image.getSubimage(1285,1263,70,94);
		punchImages[2] = image.getSubimage(1182,1263,97,94);
		punchImages[3] = image.getSubimage(1097,1243,88,114);
		punchImages[4] = image.getSubimage(997,1256,96,101);
		punchImages[5] = image.getSubimage(930,1257,66,102);
	}
	public BufferedImage damageImage() {
		if(imageIndex>=5) {
			imageIndex=0;
			currentMove = STANDING;
		}
		BufferedImage img = damageImages[imageIndex];
		imageIndex++;
		return img;
	}
	private BufferedImage powerimage() {
		if(imageIndex>8) {
			imageIndex=0;
			
			currentMove = STANDING;
			isAttacking = false;
			movepowerm();
		}
//		if(imageIndex>=4) {
//			BufferedImage img = standingImages[imageIndex];
//		
//		}
		BufferedImage img = powerimage[imageIndex];
		movepower(imageIndex);
		imageIndex++;
		
		
		return img;
	}
	private BufferedImage jumpImage() {
		if(imageIndex>5) {
			imageIndex=0;
			currentMove = STANDING;
		}
		BufferedImage img = jumpimage[imageIndex];
		imageIndex++;
		
		return img;
	}
	private BufferedImage walkImage() {
		if(imageIndex>5) {
			imageIndex=0;
			currentMove = STANDING;
		}
		BufferedImage img = walkImages[imageIndex];
		imageIndex++;
		
		return img;
	}
	private BufferedImage kickImage() {
		if(imageIndex>5) {
			imageIndex=0;
			currentMove = STANDING;
			
		}
		BufferedImage img = kickImages[imageIndex];
		imageIndex++;isAttacking = false;
		return img;
	}
	private BufferedImage punchImage() {
		if(imageIndex>5) {
			imageIndex=0;
			currentMove = STANDING;
			
		}
		BufferedImage img = punchImages[imageIndex];
		imageIndex++;isAttacking = false;
		return img;
	}
	
	private BufferedImage standingImage() {
		if(imageIndex>5) {
			imageIndex=0;
		}
		BufferedImage img = standingImages[imageIndex];
		imageIndex++;
		return img;
	}
	
	@Override
	public BufferedImage defaultImage() {
		
		 if (currentMove == WALK) {
			return walkImage();
		}
		else if(currentMove == PUNCH) {
			return punchImage();
		}
		else if(currentMove == POWER) {
			return powerimage();
		}
		else if (currentMove == KICK) {
			return kickImage();
		}
		else if (currentMove == jump) {
			return jumpImage();
		}
		if(currentMove == DAMAGE) {
				return damageImage();
			}
//		 BufferedImage subImage = image.getSubimage(1756,685,62,94);
//		 return subImage;
			return standingImage();
		
		 
		
	}
	
	
	
	
	
	
}
